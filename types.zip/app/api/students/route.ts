// import { NextRequest, NextResponse } from "next/server";
// import { prisma } from "@/lib/prisma";
// import { z } from "zod";
//
// const studentSchema = z.object({
//   name: z.string().min(1),
//   email: z.string().email(),
//   phone: z.string().min(1),
//   department: z.string().min(1),
// });
//
// export async function POST(req: NextRequest) {
//   try {
//     const body = await req.json();
//     const validated = studentSchema.parse(body);
//
//     const student = await prisma.student.create({
//       data: validated,
//     });
//
//     return NextResponse.json(student);
//   } catch (error) {
//     return NextResponse.json(
//       { error: "Failed to create student" },
//       { status: 400 }
//     );
//   }
// }
//
// export async function GET() {
//   try {
//     const students = await prisma.student.findMany({
//       orderBy: { createdAt: "desc" },
//     });
//     return NextResponse.json(students);
//   } catch (error) {
//     return NextResponse.json(
//       { error: "Failed to fetch students" },
//       { status: 500 }
//     );
//   }
// }
