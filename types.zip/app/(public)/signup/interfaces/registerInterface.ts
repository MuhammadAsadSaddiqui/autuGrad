export interface RegisterInterface {
  fullName: string;
  email: string;
  password: string;
}
